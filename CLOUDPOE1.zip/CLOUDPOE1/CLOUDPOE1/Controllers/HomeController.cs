using Microsoft.AspNetCore.Mvc;
using CLOUDPOE1.Services;
using System.Threading.Tasks;
using CLOUDPOE1.Models;

namespace CLOUDPOE1.Controllers
{
    public class HomeController : Controller
    {
        private readonly CustomerService _customerService;
        private readonly OrderService _orderService;
        private readonly BlobService _blobService;

        public HomeController(CustomerService customerService, OrderService orderService, BlobService blobService)
        {
            _customerService = customerService;
            _orderService = orderService;
            _blobService = blobService;
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> ProcessOrder(int orderId)
        {
            try
            {
                var order = await _orderService.GetOrderByIdAsync(orderId);
                if (order == null)
                {
                    TempData["ErrorMessage"] = $"Order with ID {orderId} not found.";
                    return RedirectToAction("Index");
                }

                // Implement your order processing logic here
                // For example, you could update the order status, send a notification, etc.

                TempData["SuccessMessage"] = $"Order {orderId} processed successfully.";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                // Log the exception
                TempData["ErrorMessage"] = "An error occurred while processing the order.";
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddCustomerProfile(CustomerProfile model)
        {
            if (ModelState.IsValid)
            {
                await _customerService.InsertCustomerAsync(model);
                TempData["SuccessMessage"] = "Customer profile added successfully!";
                return RedirectToAction("Index");
            }
            TempData["ErrorMessage"] = "There was an error adding the customer profile.";
            return View("Index", model);
        }

        [HttpPost]
        public async Task<IActionResult> AddOrder(Order order)
        {
            if (ModelState.IsValid)
            {
                await _orderService.AddOrderAsync(order);
                TempData["SuccessMessage"] = "Order added successfully!";
                return RedirectToAction("Index");
            }
            TempData["ErrorMessage"] = "There was an error adding the order.";
            return View("Index", order);
        }

        [HttpPost]
        public async Task<IActionResult> UploadFile(IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
                string blobUrl = await _blobService.UploadBlobAsync(file);
                TempData["SuccessMessage"] = "File uploaded successfully!";
                ViewBag.BlobUrl = blobUrl;
            }
            else
            {
                TempData["ErrorMessage"] = "Please select a file to upload.";
            }
            return RedirectToAction("Index");
        }
    }
}