﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;
using CLOUDPOE1.Models;
using Microsoft.Extensions.Configuration;

namespace CLOUDPOE1.Services
{
    public class OrderService
    {
        private readonly IConfiguration _configuration;

        public OrderService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task AddOrderAsync(Order order)
        {
            var connectionString = _configuration.GetConnectionString("SqlDatabase");
            var query = @"INSERT INTO Orders (CustomerID, OrderDate, TotalAmount, ProductID, Quantity, UnitPrice)
                  VALUES (@CustomerID, @OrderDate, @TotalAmount, @ProductID, @Quantity, @UnitPrice)";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@CustomerID", order.CustomerID);
                    command.Parameters.AddWithValue("@OrderDate", order.OrderDate);
                    command.Parameters.AddWithValue("@TotalAmount", order.TotalAmount);
                    command.Parameters.AddWithValue("@ProductID", order.ProductID);
                    command.Parameters.AddWithValue("@Quantity", order.Quantity);
                    command.Parameters.AddWithValue("@UnitPrice", order.UnitPrice);

                    await connection.OpenAsync();
                    await command.ExecuteNonQueryAsync();
                }
            }
            catch (SqlException ex)
            {
                // Log the exception
                Console.WriteLine($"Error adding order: {ex.Message}");
                throw new Exception("Failed to add the order", ex);
            }
            catch (Exception ex)
            {
                // Log the exception
                Console.WriteLine($"Error adding order: {ex.Message}");
                throw new Exception("Failed to add the order", ex);
            }
        }

        public async Task<Order> GetOrderByIdAsync(int orderId)
        {
            var connectionString = _configuration.GetConnectionString("SqlDatabase");
            var query = @"SELECT * FROM Orders WHERE OrderID = @OrderID";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@OrderID", orderId);

                    await connection.OpenAsync();
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            return new Order
                            {
                                OrderID = reader.GetInt32(reader.GetOrdinal("OrderID")),
                                CustomerID = reader.GetInt32(reader.GetOrdinal("CustomerID")),
                                OrderDate = reader.GetDateTime(reader.GetOrdinal("OrderDate")),
                                TotalAmount = reader.GetDecimal(reader.GetOrdinal("TotalAmount")),
                                ProductID = reader.GetInt32(reader.GetOrdinal("ProductID")),
                                Quantity = reader.GetInt32(reader.GetOrdinal("Quantity")),
                                UnitPrice = reader.GetDecimal(reader.GetOrdinal("UnitPrice"))
                            };
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Log the exception or rethrow it
                throw new Exception("Failed to get the order", ex);
            }

            return null;
        }

        public async Task<List<Order>> GetOrdersByCustomerIdAsync(int customerId)
        {
            var connectionString = _configuration.GetConnectionString("SqlDatabase");
            var query = @"SELECT * FROM Orders WHERE CustomerID = @CustomerID";
            var orders = new List<Order>();

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@CustomerID", customerId);

                    await connection.OpenAsync();
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            orders.Add(new Order
                            {
                                OrderID = reader.GetInt32(reader.GetOrdinal("OrderID")),
                                CustomerID = reader.GetInt32(reader.GetOrdinal("CustomerID")),
                                OrderDate = reader.GetDateTime(reader.GetOrdinal("OrderDate")),
                                TotalAmount = reader.GetDecimal(reader.GetOrdinal("TotalAmount")),
                                ProductID = reader.GetInt32(reader.GetOrdinal("ProductID")),
                                Quantity = reader.GetInt32(reader.GetOrdinal("Quantity")),
                                UnitPrice = reader.GetDecimal(reader.GetOrdinal("UnitPrice"))
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Log the exception or rethrow it
                throw new Exception("Failed to get the orders", ex);
            }

            return orders;
        }

        public async Task UpdateOrderAsync(Order order)
        {
            var connectionString = _configuration.GetConnectionString("SqlDatabase");
            var query = @"UPDATE Orders
                          SET CustomerID = @CustomerID, OrderDate = @OrderDate, TotalAmount = @TotalAmount,
                              ProductID = @ProductID, Quantity = @Quantity, UnitPrice = @UnitPrice
                          WHERE OrderID = @OrderID";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@CustomerID", order.CustomerID);
                    command.Parameters.AddWithValue("@OrderDate", order.OrderDate);
                    command.Parameters.AddWithValue("@TotalAmount", order.TotalAmount);
                    command.Parameters.AddWithValue("@ProductID", order.ProductID);
                    command.Parameters.AddWithValue("@Quantity", order.Quantity);
                    command.Parameters.AddWithValue("@UnitPrice", order.UnitPrice);
                    command.Parameters.AddWithValue("@OrderID", order.OrderID);

                    await connection.OpenAsync();
                    await command.ExecuteNonQueryAsync();
                }
            }
            catch (Exception ex)
            {
                // Log the exception or rethrow it
                throw new Exception("Failed to update the order", ex);
            }
        }

        public async Task DeleteOrderAsync(int orderId)
        {
            var connectionString = _configuration.GetConnectionString("SqlDatabase");
            var query = @"DELETE FROM Orders WHERE OrderID = @OrderID";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@OrderID", orderId);

                    await connection.OpenAsync();
                    await command.ExecuteNonQueryAsync();
                }
            }
            catch (Exception ex)
            {
                // Log the exception or rethrow it
                throw new Exception("Failed to delete the order", ex);
            }
        }
    }
}