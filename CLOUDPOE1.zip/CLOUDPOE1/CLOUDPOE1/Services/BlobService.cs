﻿using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using System.Threading.Tasks;

namespace CLOUDPOE1.Services
{
    public class BlobService
    {
        private readonly BlobServiceClient _blobServiceClient;

        public BlobService(IConfiguration configuration)
        {
            var connectionString = configuration.GetSection("AzureStorage:ConnectionString").Value;
            _blobServiceClient = new BlobServiceClient(connectionString);
        }

        public async Task<string> UploadBlobAsync(IFormFile file)
        {
            if (file == null || file.Length == 0)
                throw new ArgumentException("File cannot be null or empty", nameof(file));

            // Get the container (you can replace 'my-container' with your container name)
            var containerClient = _blobServiceClient.GetBlobContainerClient("my-container");
            await containerClient.CreateIfNotExistsAsync();

            // Create a unique name for the blob
            string blobName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
            var blobClient = containerClient.GetBlobClient(blobName);

            // Upload the file to Azure Blob Storage
            using (var stream = file.OpenReadStream())
            {
                await blobClient.UploadAsync(stream);
            }

            return blobClient.Uri.ToString(); // Return the URI of the uploaded blob
        }

        internal async Task InsertBlobAsync(byte[] imageData)
        {
            throw new NotImplementedException();
        }
    }
}
